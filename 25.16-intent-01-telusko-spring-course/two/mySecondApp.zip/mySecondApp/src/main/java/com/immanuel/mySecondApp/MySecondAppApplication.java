package com.immanuel.mySecondApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySecondAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySecondAppApplication.class, args);
	}

}
